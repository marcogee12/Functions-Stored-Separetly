import os
import MyLib

# Program name : Wk5_Marco_Gomez.py
# Student Name : Marco Gomez
# Course : ENTD220
# Instructor : Robert Haluska
# Date : 01/08/2021
# Copy Wrong : This is my work

LoopInput = "y"

while (LoopInput != "n"):
    success = False
    #Takes user input for the ranges of numbers abled to be used for the calculations
    while success != True:
        try:
            Num1 = float(input("Enter the lower range of the the number. Anything lower than this number will not be able to be calculated. \n"))
            success = isinstance(Num1, float)
        except:
            print("The input range provided isnt a number.")
            success = False
            
    success = False

    while success != True:
            try:
                Num2 = float(input("Enter the higher range of the the number. Anything over this number will not be able to be calculated. \n"))
                success = isinstance(Num2, float)
            except:
                print("The input range provided isn't a number.")
                success = False

    NumCalc1 = float(0)
    NumCalc2 = float(0)

    #Takes user input for the first and second numbers only if they are in between the previously specified range and not equal to 0.
    #the program will keep asking if it does not meet the criteria.
    success = False
    while success != True:
        while (NumCalc1 < Num1 or NumCalc1 > Num2 or NumCalc1 == 0):
            try:
                NumCalc1 = float(input("Please enter between " + str(Num1) + " and " + str(Num2) + " for the first number for simple calulations. \n"))
                success = isinstance(NumCalc1, float)
            except:
                print("The input isn't a number.")
                success = False
            if (NumCalc1 < Num1 or NumCalc1 > Num2 or NumCalc1 == 0):
                try:
                    print("Please enter a number between " + str(Num1) + " and " + str(Num2) + " The number also cannot be 0.")
                    check_user_input(NumCalc1)
                    success = isinstance(NumCalc1, float)
                except:
                    print("The input isn't a number.")
                    success = False

    success = False
    while success != True:
        while (NumCalc2 < Num1 or NumCalc2 > Num2 or NumCalc2 == 0):
            try:
                NumCalc2 = float(input("Please enter between " + str(Num1) + " and " + str(Num2) + " for the second number for simple calulations. \n"))
                success = isinstance(NumCalc2, float)
            except: 
                print("The input isn't a number.")
            if (NumCalc2 < Num1 or NumCalc2 > Num2 or NumCalc2 == 0):
                try:
                    print("Please enter a number between " + str(Num1) + " and " + str(Num2) + " The number also cannot be 0.")
                    success = isinstance(NumCalc2, float)
                except:
                    print("The input isn't a number.")


    MyLib.summ(NumCalc1, NumCalc2)
    MyLib.subtract(NumCalc1, NumCalc2)
    MyLib.division(NumCalc1, NumCalc2)
    MyLib.multiply(NumCalc1, NumCalc2)

    equation = input("Please enter a calculation you would like to have calculated: \n")

    MyLib.scalc(equation)

    LoopInput = input("Would you like to run this program again? \n")