# Program name : MyLib.py
# Student Name : Marco Gomez
# Course : ENTD220
# Instructor : Robert Haluska
# Date : 01/08/2021
# Copy Wrong : This is my work

def summ(numOne, numTwo):
    try:
        total = numOne + numTwo
        print("The sum of these numbers is " + str(total))
    except: 
        print("The numbers provided cannot be added.")

def subtract(numOne, numTwo):
    try:
        total = numOne - numTwo
        print("The subtraction of these numbers is " + str(total))
    except:
        print("The numberes provided cannot be subtracted.")

def division(numOne, numTwo):
    try:
        total = numOne / numTwo
        print("The divison of these numbers is " + str(total))
    except:
        print("The numbers provided cannot be divided")

def multiply(numOne, numTwo):
    try:
        total = numOne * numTwo
        print("The product of these numbers is " + str(total))
    except:
        print("The numbers provided cannot be multiplied.")

def scalc(equation):
    try:
        if '+' in equation:
            y = equation.split('+')
            x = float(y[0])+float(y[1])
        elif '-' in equation:
            y = equation.split('-')
            x = float(y[0])-float(y[1])
        elif '/' in equation:
            y = equation.split('/')
            x = float(y[0])/float(y[1])
        elif '*' in equation:
            y = equation.split('*')
            x = float(y[0])-float(y[1])
        return print(str(x))
    except:
        print("The numbers provided cannot be calculated.")

